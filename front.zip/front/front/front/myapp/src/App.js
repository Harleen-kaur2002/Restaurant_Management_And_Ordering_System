import React, { useState } from 'react';
import './App.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import NavigationBar from './components/NavigationBar/NavigationBar';
import Home from './components/Home/Home';
import Footer from './components/Footer/Footer';
import Categories from './components/Categories/Categories';
import AllCategories from './components/AllCategories/AllCategories';
import OrderCart from './components/Order/OrderCart';
import Login from './components/AdminLogin/Login';
import HomeDashboard from './components/AdminDashboard/DashboardHome/HomeDashboard';

const App = () => {
  const [cartItems, setCartItems] = useState([]); // Cart state

  // Function to add items to the cart
  const addToCart = (item, spiceLevel) => {
    const existingItemIndex = cartItems.findIndex(cartItem =>
      cartItem._id === item._id && cartItem.spiceLevel === spiceLevel
    );
  
    if (existingItemIndex !== -1) {
      // If exact item with same spiceLevel exists, increase quantity
      const updatedCartItems = [...cartItems];
      updatedCartItems[existingItemIndex].quantity += 1;
      setCartItems(updatedCartItems);
    } else {
      // Add as a new item with selected spice level
      setCartItems([...cartItems, { ...item, spiceLevel, quantity: 1 }]);
    }
  };
  
  // Define the routes
  const router = createBrowserRouter([
    {
      path: "/",
      element: (
        <div>
          <NavigationBar />
          <Home />
          <Categories />
          <Footer />
        </div>
      ),
    },
    {
      path: "/login",
      element: (
        <div>
          <NavigationBar />
          <Home />
          <Login />
          <Footer />
        </div>
      ),
    },
    {
      path: "/admin-dashboard",
      element: (
        <div>
          <NavigationBar />
          <HomeDashboard />
          <Footer />
        </div>
      ),
    },
    {
      path: "/:category",
      element: (
        <div>
          <NavigationBar />
          <div className="main-content">
            <AllCategories addToCart={addToCart} /> {/* Pass addToCart function */}
            <OrderCart cartItems={cartItems} /> {/* Pass cartItems */}
          </div>
          <Footer />
        </div>
      ),
    },
  ]);

  return (
    <div className="App">
      <RouterProvider router={router} />
    </div>
  );
};

export default App;
