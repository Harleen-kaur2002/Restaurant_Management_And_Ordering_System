import React from 'react';
import './Categories.css';
import { NavLink } from 'react-router-dom';
import home from '../images/home.jpg'

const categories = [
  { name: 'Appetizers', link: '/appetizers', image:home },
  { name: 'Main Course', link: '/main-course', image:home  },
  { name: 'Beverages', link: '/beverages', image: home  },
  { name: 'Desserts', link: '/desserts', image: home  },
  { name: 'Soups', link: '/soups', image:home  },
  { name: 'Salads', link: '/salads', image: home  },
  { name: 'Sides', link: '/sides', image: home  },
  { name: 'Fast Food', link: '/fast-food', image: home },
];

const Categories = () => {
  return (
    <div className="categories-container">
      <h3 className="categories-title">Categories</h3>
      <div className="category-cards-wrapper">
        {categories.map((category, index) => (
          <NavLink to={category.link} key={index} className="category-card">
            <img src={category.image} alt={category.name} className="category-image" />
            <div className="category-content">
              <h4 className="category-name">{category.name}</h4>
            </div>
          </NavLink>
        ))}
      </div>
    </div>
  );
};

export default Categories;
