import React from 'react';
import './OrderCart.css';
import { useNavigate } from 'react-router-dom';

const OrderCart = ({ cartItems }) => {
  const navigate = useNavigate();

  // Calculate total
  const calculateTotal = () => {
    const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
    const taxRate = 0.10; // 10% tax
    const taxAmount = subtotal * taxRate;
    const total = subtotal + taxAmount;
    return {
      subtotal: subtotal.toFixed(2),
      tax: taxAmount.toFixed(2),
      total: total.toFixed(2),
    };
  };

  const handleMobileRedirect = () => {
    if (window.innerWidth < 768) {
      navigate('/order-summary');
    }
  };

  const { subtotal, tax, total } = calculateTotal();

  return (
    <div className="order-cart" onClick={handleMobileRedirect}>
      <h3>Your Order</h3>
      <ul>
        {cartItems.map((item, index) => (
          <li key={index}>
            <span>{item.name} (x{item.quantity})</span>
            {item.spiceLevel && <span> - Spice Level: {item.spiceLevel}</span>}
            <span> - ${item.price * item.quantity}</span>
          </li>
        ))}
      </ul>
      <p>Subtotal: ${subtotal}</p>
      <p>Tax (10%): ${tax}</p>
      <p>Total: ${total}</p>
      <button onClick={() => navigate('/order-summary')}>Checkout</button>
    </div>
  );
};

export default OrderCart;
