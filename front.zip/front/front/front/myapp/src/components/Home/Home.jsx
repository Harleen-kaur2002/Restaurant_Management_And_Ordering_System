import React from 'react'
import homeImage from '../images/homeImage.jpg';
import './Home.css'
const Home = () => {
  return (
    <div>
       <div className='home-container'>
      <div className='home-banner-container'>
        <img src={homeImage} alt="Jewellery Background" className="background-image"/>
        </div>
        </div>
    </div>
  )
}

export default Home
