import React, { useEffect, useState } from 'react';
import axios from 'axios';

const HomeDashboard = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/api/orders')
      .then(response => {
        setOrders(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the orders!', error);
      });
  }, []);

  return (
    <div>
      <h2>Dashboard</h2>
      <table>
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Customer ID</th>
            <th>Order Time</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(order => (
            <tr key={order.orderId}> {/* Changed to orderId */}
              <td>{order.orderId}</td>
              <td>{order.customerId}</td> {/* Changed to customerId */}
              <td>{order.orderTime}</td> {/* Changed to orderTime */}
              <td>{order.orderStatus}</td> {/* Changed to orderStatus */}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};


export default HomeDashboard;
