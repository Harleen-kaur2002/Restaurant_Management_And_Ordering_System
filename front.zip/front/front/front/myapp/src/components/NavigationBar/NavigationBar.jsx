import React, { useState } from 'react';
import './NavigationBar.css';
import { NavLink } from 'react-router-dom';

const NavigationBar = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(false); 

    
    const handleLogin = () => {
        setIsLoggedIn(true); 
    };

    return (
        <div className='navbar'>
            <div className='nav-name'>
                <p>Restaurant Management System</p>
            </div>
            <div className='nav-login'>
                
                    <NavLink to="/login">
                        <button type="button" onClick={handleLogin}>Login</button>
                    </NavLink>
               
            </div>
        </div>
    );
};

export default NavigationBar;
