import React from 'react'
import './Footer.css'
const Footer = () => {
  return (
    <div>
      <footer className="footer">
        <p>Copyright</p>
      </footer>
    </div>
  )
}

export default Footer
