import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import './AllCategories.css';

const AllCategories = ({ addToCart }) => {
  const { category } = useParams();
  const [menu, setMenu] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null); // Track selected item
  const [spiceLevel, setSpiceLevel] = useState(''); // Track selected spice level

  useEffect(() => {
    const fetchMenuItem = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/menu/${category}`);
        setMenu(response.data);
      } catch (error) {
        console.error('Error fetching menu items:', error);
      }
    };
    fetchMenuItem();
  }, [category]);

  const handleAddToCart = (item) => {
    setSelectedItem(item); // Set the item that was clicked
  };

  const handleCustomize = () => {
    if (selectedItem && spiceLevel) {
      // Add the selected item to the cart with the chosen spice level
      addToCart(selectedItem, spiceLevel);
      // Reset customization modal and cart states
      setSelectedItem(null);
      setSpiceLevel('');
    } else {
      // Show an alert if no spice level is selected
      alert('Please select a spice level before adding to cart!');
    }
  };

  return (
    <div className='menu-page'>
      <h1>{category} Collection</h1>
      <div className='menu-items'>
        {menu.map((item) => (
          <div className='menu-item' key={item._id}>
            <img src={`http://localhost:8080${item.image}`} alt={item.name} className='menu-image' />
            <h2 className='menu-name'>{item.name}</h2>
            <p className="price">${item.price}</p>
            <button className="add-to-cart" onClick={() => handleAddToCart(item)}>Add to Cart</button>
          </div>
        ))}
      </div>

      {selectedItem && (
        <div className="customization-modal">
          <h3>Customize your {selectedItem.name}</h3>
          <label>Spice Level:</label>
          <select value={spiceLevel} onChange={(e) => setSpiceLevel(e.target.value)}>
            <option value="">Select spice level</option>
            <option value="Mild">Mild</option>
            <option value="Medium">Medium</option>
            <option value="Hot">Hot</option>
          </select>
          <button onClick={handleCustomize}>Add to Cart</button>
          <button onClick={() => setSelectedItem(null)}>Cancel</button>
        </div>
      )}
    </div>
  );
};

export default AllCategories;
