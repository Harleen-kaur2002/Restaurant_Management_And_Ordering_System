import React, { useState } from 'react';
import './Login.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();  

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
          
            const response = await axios.post("http://localhost:8080/login", {
                username,
                password,
            });

            console.log(response.data); // Log response for debugging
            alert(response.data.message); 
         
            if (response.status === 200) {
                navigate("/admin-dashboard"); // Redirect to admin dashboard
            }
        } catch (error) {
            console.log(error); // Log any error
            alert("Login failed! Please check your credentials.");
        }
    };

    return (
        <div className="login-container">
            <h2>Admin Login</h2>
            <form onSubmit={handleSubmit} className="login-form">
                <input
                    type="text"
                    placeholder="Enter Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="input-field"
                    required
                />
                <input
                    type="password"
                    placeholder="Enter Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="input-field"
                />
                <button type="submit" className="login-button">Login</button>
            </form>
        </div>
    );
};

export default Login;
